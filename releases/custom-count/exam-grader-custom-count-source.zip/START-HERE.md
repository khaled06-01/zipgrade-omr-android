# Teacher-created answer sheets

## On Android

1. Open **Scan → Create answer sheet**. Enter any whole number from 1 through 100. Arabic numerals such as ٣٧ also work.
2. Tap **Create PDF**, choose where to save it, and print on portrait A4 at actual size (100%). Keep the six black squares and the count strip in view.
3. In **Key**, choose the correct A–D answer for each row and tap **Use this answer key**.
4. In **Scan**, select **Auto** and scan the completed sheet with the live camera or import a portrait image. Check the detected count and the seven-digit student ID, then tap **Review / save grade**. Resolve flagged marks before saving.
5. When switching between exams of the same length, check the key. The strip carries the layout version and question count. The app currently keeps one local answer key and gradebook.

## Try the included 37-question example

The PDF is blank and printable. The separate PNG contains the synthetic student ID 0033166. The answers repeat A, B, C, D starting at question 1, and question 37 is A. Import this PNG in Auto to see the detected count before printing anything. With the matching key confirmed, the expected score is 37/37.

## Sheet-X

Open the project in the sheet-x directory. In single-sheet view, set **مخصص** to the desired number and choose **تنزيل ورقة ماسح فارغة**. The resulting A4 SVG prints at 100% and uses the same count strip as Android. **تنزيل بالتظليل الحالي** includes the marks currently on screen for scanner tests.

## تجربة سريعة

من شاشة المسح اختر **إنشاء ورقة إجابة**، ثم أدخل عدد الأسئلة من ١ إلى ١٠٠ واحفظ ملف PDF. اطبع الورقة على A4 بالحجم الفعلي. حدّد الإجابات الصحيحة في تبويب مفتاح الإجابة واضغط **اعتماد مفتاح الإجابة**. عند مسح الورقة في الوضع التلقائي، يظهر عدد الأسئلة الذي قرأه التطبيق من الشريط المطبوع. إذا استخدمت اختبارين بنفس عدد الأسئلة، راجع المفتاح عند التبديل بينهما.

## Validation and distribution

Each Android question count has been checked by rendering the generated PDF, reading the blank page, then reading a digitally filled version with a known ID and answer key. Gallery checks on the 37-question example also covered dim light, simulated shadow and noise, and rotations of 8 degrees in either direction. At 15 degrees the sample lost alignment. Physical printer and phone-camera testing remains open.

The installable APK uses the development signing key. The Google Play App Bundle targets Android API 36 and requires your private upload key before submission. Android build commands are in zipgrade-omr-android/BUILDING.md. Web build and form export instructions are in sheet-x/SCANNER-FIXTURES.md.
