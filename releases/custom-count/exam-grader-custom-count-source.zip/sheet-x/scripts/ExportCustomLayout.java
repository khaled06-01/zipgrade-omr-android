import com.zipgrade.omrscanner.CustomSheetLayout;
import java.util.ArrayList;
import java.util.List;

/** Emits the browser copy of the Android layout. Run through sync-custom-layout.sh with JDK 17. */
public final class ExportCustomLayout {
    public static void main(String[] args) {
        int max = CustomSheetLayout.MAX_COUNT;
        List<String> rows = new ArrayList<>();
        for (int q = 1; q <= max; q++) {
            List<Float> xs = new ArrayList<>();
            for (int option = 0; option < 4; option++) xs.add(CustomSheetLayout.answerX(max, q, option));
            rows.add("{\"y\":" + CustomSheetLayout.answerY(max, q) + ",\"xs\":" + xs + "}");
        }
        List<String> fiducials = new ArrayList<>(), cells = new ArrayList<>(), words = new ArrayList<>();
        for (int i = 0; i < 6; i++)
            fiducials.add("[" + CustomSheetLayout.fiducialX(i) + ", " + CustomSheetLayout.fiducialY(i) + "]");
        for (int i = 0; i < CustomSheetLayout.CELL_COUNT; i++)
            cells.add("[" + CustomSheetLayout.cellX(i) + ", " + CustomSheetLayout.cellY(i) + "]");
        for (int n = CustomSheetLayout.MIN_COUNT; n <= max; n++) {
            for (int q = 1; q <= n; q++) {
                for (int option = 0; option < 4; option++)
                    if (CustomSheetLayout.answerX(n, q, option) != CustomSheetLayout.answerX(max, q, option)
                            || CustomSheetLayout.answerY(n, q) != CustomSheetLayout.answerY(max, q))
                        throw new IllegalStateException("Non-prefix layout for " + n + " questions");
            }
            StringBuilder bits = new StringBuilder();
            for (int cell = 0; cell < CustomSheetLayout.CELL_COUNT; cell++)
                bits.append(CustomSheetLayout.isDark(n, cell) ? '1' : '0');
            words.add("    [\"" + CustomSheetLayout.code(n) + "\",\"" + bits + "\"]");
        }
        List<Float> idX = new ArrayList<>(), idY = new ArrayList<>();
        for (int col = 0; col < 7; col++) idX.add(CustomSheetLayout.idX(col));
        for (int digit = 0; digit < 10; digit++) idY.add(CustomSheetLayout.idY(digit));
        System.out.println("{\n  \"markerHalfSize\": " + CustomSheetLayout.MARKER_HALF_SIZE
            + ",\n  \"markerCentres\": " + fiducials + ",\n  \"cellSize\": " + CustomSheetLayout.CELL_SIZE
            + ",\n  \"cellCentres\": " + cells + ",\n  \"answerRadius\": " + CustomSheetLayout.ANSWER_RADIUS
            + ",\n  \"idRadius\": " + CustomSheetLayout.ID_RADIUS + ",\n  \"idX\": " + idX + ",\n  \"idY\": " + idY
            + ",\n  \"rows\": [\n    " + String.join(",\n    ", rows)
            + "\n  ],\n  \"codes\": [\n" + String.join(",\n", words) + "\n  ]\n}");
    }
}
