#!/usr/bin/env python3
"""Fail if Android's duplicated coordinate table drifts from the candidate JSON contract."""
import json
from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit('Usage: python scripts/verify-android-template-contract.py /path/to/OmrNativeCvEngine.java')
contract = json.loads((Path(__file__).resolve().parents[1] / 'src/templates/sheetx-v1.json').read_text())
java = Path(sys.argv[1]).read_text()
part = java[java.index('private static final TemplateSpec[] ALL_TEMPLATES'):]
pattern = r'new TemplateSpec\(\s*"(SHEETX_\d+Q)",\s*(\d+),\s*"[^"]+",\s*new ColSpec\[\] \{(.*?)\},\s*([\d.f,\s]+)\)'
actual = {}
for code, count, columns, idvalues in re.findall(pattern, part, re.S):
    cols = [[float(x.strip().rstrip('f')) for x in v.split(',')] for v in re.findall(r'new ColSpec\(([^)]+)\)', columns)]
    actual[code] = (int(count), cols, [float(x.strip().rstrip('f')) for x in idvalues.split(',')])
assert len(actual) == len(contract['templates']), 'Missing or extra SHEETX template'
for template in contract['templates']:
    cols = [[col[key] for key in ['startQuestion', 'endQuestion', 'baseX', 'stepX', 'baseY', 'stepY', 'radius']] for col in template['columns']]
    grid = [template['studentId'][key] for key in ['baseX', 'stepX', 'baseY', 'stepY', 'radius']]
    assert actual[template['id']] == (template['questionCount'], cols, grid), f"Coordinate drift: {template['id']}"
for marker in contract['markers']['centres']:
    for axis in ['X', 'Y']:
        value = re.search(rf"CANON_{marker['name']}_{axis}\s*=\s*([\d.]+)f", java)
        assert value and float(value[1]) == marker[axis.lower()], f"Marker drift: {marker['name']} {axis}"
for axis, dimension in [('W', 'width'), ('H', 'height')]:
    value = re.search(rf'CANONICAL_{axis}\s*=\s*(\d+)', java)
    assert value and int(value[1]) == contract['canonical'][dimension], f'Canonical {axis} drift'
print(f"PASS: all {len(actual)} SHEETX templates and six marker centres match Android")
