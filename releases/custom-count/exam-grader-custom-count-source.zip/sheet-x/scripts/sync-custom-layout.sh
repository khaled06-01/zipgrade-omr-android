#!/bin/sh
set -eu
repo=$(CDPATH='' cd -- "$(dirname -- "$0")/.." && pwd)
android_layout=${1:-"$repo/../zipgrade-omr-android/app/src/main/java/com/zipgrade/omrscanner/CustomSheetLayout.java"}
dest="$repo/src/templates/custom-android-v1.json"
scratch=$(mktemp -d)
trap 'rm -rf "$scratch"' EXIT
javac --release 17 -d "$scratch" "$android_layout" "$repo/scripts/ExportCustomLayout.java"
java -cp "$scratch" ExportCustomLayout > "$scratch/layout.json"
case ${2:-check} in
  update) cp "$scratch/layout.json" "$dest" ;;
  check) diff -u "$dest" "$scratch/layout.json" ;;
  *) echo "Use check or update." >&2; exit 2 ;;
esac
