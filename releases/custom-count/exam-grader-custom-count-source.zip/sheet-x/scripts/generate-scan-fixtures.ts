import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { buildScannerFixture, scannerTemplateContract, type FixtureMarks } from '../src/utils/scannerFixture';
import type { OptionKey } from '../src/utils/omrLogic';

const output = resolve(process.argv[2] ?? 'work/scan-fixtures');
await mkdir(output, { recursive: true });
for (const template of scannerTemplateContract.templates) {
  const answers: Record<number, OptionKey[]> = {};
  for (let q = 1; q <= template.questionCount; q++) answers[q] = [(['A', 'B', 'C', 'D'] as const)[(q - 1) % 4]];
  const cases: Record<string, FixtureMarks> = {
    clean: { answers, idDigits: '0033166'.split('').map((digit) => [Number(digit)]) },
    blank: { answers: {}, idDigits: Array.from({ length: 7 }, () => []) },
    review: { answers: { ...answers, 1: ['A', 'B'], 2: [], 3: ['C', 'D'] }, idDigits: [[0, 1], [0], [3], [3], [1], [6], [6]] },
  };
  for (const [name, marks] of Object.entries(cases)) {
    const fixture = await buildScannerFixture(template.questionCount, marks);
    const base = `${output}/${template.id.toLowerCase()}-${name}`;
    await writeFile(`${base}.svg`, fixture.svg);
    await writeFile(`${base}.a4.svg`, fixture.pageSvg);
    await writeFile(`${base}.truth.json`, `${JSON.stringify(fixture.truth, null, 2)}\n`);
  }
}
console.log(`Wrote 18 synthetic SVG/truth fixture pairs and A4 versions to ${output}`);
