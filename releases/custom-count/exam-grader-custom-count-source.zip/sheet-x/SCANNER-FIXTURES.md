# Sheet-X scanner forms

In the single-sheet view, choose a whole question count from **1 to 100** using the **مخصص** field. Click **تنزيل ورقة ماسح فارغة** for a blank A4 form, or **تنزيل بالتظليل الحالي** for a test copy that includes the filled answers and student ID. A 37-question form carries its own count in the printed strip and has exactly 37 rows. Open the SVG in a print viewer and print at 100%. Scan in the updated Android app using Auto. The browser’s ordinary Print button prints the responsive layout.

The web exporter uses a snapshot of the Android `CustomSheetLayout` coordinates and count codes. To verify the checked-in snapshot, run `scripts/sync-custom-layout.sh` with JDK 17 on the path and the two source checkouts side by side. To regenerate after an Android format change, pass the Java file path followed by `update`. The exporter checks that every supported question count uses a prefix of the same positions before emitting the data.

## Legacy fixed-layout test fixtures

These fixtures retain the original six Sheet-X preset layouts for regression testing. Their A4 marker spacing is 141.6 mm, and they use explicit Sheet-X mode when scanning. Custom-count forms above use their own geometry and printed marker.



Use Node 24 and install dependencies with `npm ci`. Run these commands from this repository:

```sh
npm test
npm run lint
npm run build
npm run fixtures
python3 scripts/verify-android-template-contract.py ../zipgrade-omr-android/app/src/main/java/com/zipgrade/omrscanner/OmrNativeCvEngine.java
```

The generator writes to `work/scan-fixtures/`. Use `npm run fixtures -- /path/to/directory` to choose another destination. Each of the six template sizes (10, 16, 20, 30, 50 and 100) has three cases:

| Filename suffix | Expected observations |
| --- | --- |
| clean | Answers A, B, C, D repeating from Q1. Scan code 0033166. |
| blank | All answers and ID columns empty. This requires identity review. |
| review | Q1 has A+B, Q2 is empty, Q3 has C+D. The first ID column contains 0 and 1, so the ID is unresolved (?033166). |

Use `.truth.json` to compare individual detected marks and the scan code. Use `.a4.svg` for paper and `.svg` for a cropped canonical scanner input. With Inkscape installed, make an image and printable PDF as follows:

```sh
cd work/scan-fixtures
inkscape sheetx_10q-clean.svg --export-width=600 --export-height=780 --export-filename=sheetx_10q-clean.png
inkscape sheetx_10q-clean.a4.svg --export-text-to-path --export-filename=sheetx_10q-clean.a4.pdf
```

The manifest in `src/templates/sheetx-v1.json` records the coordinates, A4 transform, and Android revision they came from. The Python check compares all six definitions to Android's Java table and fails on coordinate drift. Synthetic exports contain no machine-readable exam identity. Physical accuracy, phone camera behavior, and printer scaling need separate measurements on the intended devices.
