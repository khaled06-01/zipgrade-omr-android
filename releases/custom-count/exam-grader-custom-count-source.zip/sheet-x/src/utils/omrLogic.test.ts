import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getSheetLayout,
  toggleQuestionOption,
  toggleIdBubble,
  gradeSheet,
  generateDefaultAnswerKey,
  REFERENCE_SHADED_ANSWERS,
  createBlankIdColumns,
} from './omrLogic';

test('getSheetLayout produces complete question sequences for 10, 16, 20, 30, 50, and 100 questions', () => {
  const counts = [10, 16, 20, 30, 50, 100];

  for (const count of counts) {
    const layout = getSheetLayout(count);
    assert.equal(layout.questionCount, count);

    const allQuestions = [
      ...layout.fullColumns.flat(),
      ...layout.idColumnQuestions,
    ];
    assert.equal(allQuestions.length, count, `Count ${count} should include all questions`);
    assert.equal(allQuestions[0], 1);
    assert.equal(allQuestions[allQuestions.length - 1], count);

    // Ensure strict 1..N ordering without duplicates
    for (let i = 0; i < count; i++) {
      assert.equal(allQuestions[i], i + 1);
    }
  }
});

test('16-question layout matches reference image split (1..13 on left, 14..16 above ID block)', () => {
  const layout = getSheetLayout(16);
  assert.equal(layout.fullColumns.length, 1);
  assert.deepEqual(layout.fullColumns[0], [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]);
  assert.deepEqual(layout.idColumnQuestions, [14, 15, 16]);
});

test('toggleQuestionOption supports both multi-shade and singleChoiceLock modes', () => {
  let state = toggleQuestionOption({}, 12, 'B', false);
  assert.deepEqual(state[12], ['B']);

  // Add second bubble in multi-shade mode (like Q12 in reference image)
  state = toggleQuestionOption(state, 12, 'C', false);
  assert.deepEqual(state[12], ['B', 'C']);

  // Single choice lock replaces with single selection
  state = toggleQuestionOption(state, 12, 'A', true);
  assert.deepEqual(state[12], ['A']);

  // Clicking same option in single choice lock clears it
  state = toggleQuestionOption(state, 12, 'A', true);
  assert.equal(state[12], undefined);
});

test('toggleIdBubble updates shadedDigits and syncs writtenDigit', () => {
  let cols = createBlankIdColumns();
  cols = toggleIdBubble(cols, 0, 4, true);
  assert.deepEqual(cols[0].shadedDigits, [4]);
  assert.equal(cols[0].writtenDigit, '4');

  cols = toggleIdBubble(cols, 0, 4, true);
  assert.deepEqual(cols[0].shadedDigits, []);
  assert.equal(cols[0].writtenDigit, '');
});

test('gradeSheet detects correct, wrong, unanswered, and double-marked questions', () => {
  const key = generateDefaultAnswerKey(16);
  const summary = gradeSheet(16, REFERENCE_SHADED_ANSWERS, key);

  assert.equal(summary.totalQuestions, 16);
  // Q12 has both B and C shaded in REFERENCE_SHADED_ANSWERS
  assert.equal(summary.results[12].status, 'double-marked');
  assert.equal(summary.doubleMarkedCount, 1);
  assert.equal(summary.correctCount, 15);
  assert.equal(summary.wrongCount, 0);
  assert.equal(summary.unansweredCount, 0);
});
