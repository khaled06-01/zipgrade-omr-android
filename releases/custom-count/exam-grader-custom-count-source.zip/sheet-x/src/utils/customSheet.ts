import layout from '../templates/custom-android-v1.json';
import { validateMarks, type FixtureMarks } from './scannerFixture';
import type { OptionKey } from './omrLogic';

const OPTIONS: OptionKey[] = ['A', 'B', 'C', 'D'];
const BLANK: FixtureMarks = { answers: {}, idDigits: Array.from({ length: 7 }, () => []) };

export function buildCustomSheet(questionCount: number, marks: FixtureMarks = BLANK) {
  if (!Number.isInteger(questionCount) || questionCount < 1 || questionCount > layout.codes.length) {
    throw new Error('Choose a whole question count from 1 to 100');
  }
  validateMarks({ questionCount }, marks);
  const [templateId, bits] = layout.codes[questionCount - 1];
  const ink = '#000';
  const output: string[] = [];
  const square = (x: number, y: number, size: number, attrs: string) => {
    output.push(`<rect ${attrs} x="${x - size / 2}" y="${y - size / 2}" width="${size}" height="${size}" fill="${ink}"/>`);
  };
  const label = (x: number, y: number, value: string | number, anchor = 'start', size = 9) => {
    output.push(`<text x="${x}" y="${y}" text-anchor="${anchor}" font-size="${size}">${value}</text>`);
  };
  const bubble = (x: number, y: number, radius: number, marked: boolean, attrs: string) => {
    output.push(`<circle ${attrs} cx="${x}" cy="${y}" r="${radius}" stroke="#6b7376" stroke-width="0.75" fill="${marked ? ink : 'white'}"/>`);
  };

  label(300, 32, `Answer sheet · ${questionCount} questions`, 'middle', 16);
  layout.markerCentres.forEach(([x, y], i) => square(x, y, 2 * layout.markerHalfSize, `data-marker="${i}"`));
  layout.cellCentres.forEach(([x, y], i) => {
    if (bits[i] === '1') square(x, y, layout.cellSize, `data-count-cell="${i}"`);
  });
  label(96, 110, 'Name / اسم الطالب');
  output.push('<path d="M96 132 H270" stroke="#6b7376" stroke-width="0.75"/>');
  label(96, 160, 'Class / الصف');
  output.push('<path d="M96 182 H270" stroke="#6b7376" stroke-width="0.75"/>');
  label(layout.idX[0], 87, 'Student ID / رقم الطالب');
  layout.idY.forEach((y, digit) => {
    label(layout.idX[0] - 12, y + 3, digit, 'end');
    layout.idX.forEach((x, col) => bubble(x, y, layout.idRadius, marks.idDigits[col].includes(digit), `data-id-column="${col}" data-digit="${digit}"`));
  });
  const columns = new Set<number>();
  layout.rows.slice(0, questionCount).forEach(({ y, xs }, index) => {
    if (!columns.has(xs[0])) {
      xs.forEach((x, i) => label(x, y - 10, OPTIONS[i], 'middle'));
      columns.add(xs[0]);
    }
    const q = index + 1;
    label(xs[0] - 12, y + 3, q, 'end');
    xs.forEach((x, opt) => bubble(x, y, layout.answerRadius, (marks.answers[q] ?? []).includes(OPTIONS[opt]), `data-question="${q}" data-option="${OPTIONS[opt]}"`));
  });
  label(300, 754, 'A4 · Print at 100% / اطبع بالحجم الفعلي', 'middle');
  const pageSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="210mm" height="297mm" viewBox="0 0 595 842">
<title>${templateId}</title><rect width="595" height="842" fill="white"/>
<g transform="translate(-2.5 31)" font-family="sans-serif">${output.join('\n')}</g></svg>\n`;
  return { templateId, pageSvg };
}
