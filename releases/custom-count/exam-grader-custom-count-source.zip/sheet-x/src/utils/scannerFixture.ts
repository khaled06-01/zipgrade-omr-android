import contract from '../templates/sheetx-v1.json';
import type { OptionKey } from './omrLogic';

export const scannerTemplateContract = contract;
export type ScannerTemplate = (typeof contract.templates)[number];
export interface FixtureMarks {
  answers: Record<number, OptionKey[]>;
  /** Seven independent digit columns. Empty/multiple columns are deliberately unresolved. */
  idDigits: number[][];
}

export function getScannerTemplate(questionCount: number): ScannerTemplate {
  const template = contract.templates.find((candidate) => candidate.questionCount === questionCount);
  if (!template) throw new Error(`No fixed scanner template for ${questionCount} questions`);
  return template;
}

export function validateMarks(template: { questionCount: number }, marks: FixtureMarks): void {
  if (marks.idDigits.length !== contract.idColumns) throw new Error('Exactly seven ID columns are required');
  for (const digits of marks.idDigits) {
    if (new Set(digits).size !== digits.length || digits.some((digit) => !Number.isInteger(digit) || digit < 0 || digit > 9)) {
      throw new Error('ID marks must contain distinct digits from 0 to 9');
    }
  }
  for (const [question, options] of Object.entries(marks.answers)) {
    const q = Number(question);
    if (!Number.isInteger(q) || q < 1 || q > template.questionCount) throw new Error('Answer is outside this template');
    if (new Set(options).size !== options.length || options.some((option) => !contract.options.includes(option))) {
      throw new Error('Answer marks must contain distinct supported options');
    }
  }
}

function n(value: number): string {
  return Number(value.toFixed(4)).toString();
}

function renderSheet(template: ScannerTemplate, marks: FixtureMarks): string {
  const output = [
    `<rect width="600" height="780" fill="white"/>`,
    `<text x="300" y="25" text-anchor="middle" font-family="sans-serif" font-size="12">${template.id} — TEST SHEET</text>`,
    `<text x="300" y="758" text-anchor="middle" font-family="sans-serif" font-size="8">Experimental geometry v1 / four choices / print at 100%</text>`,
  ];
  for (const marker of contract.markers.centres) {
    output.push(`<rect data-marker="${marker.name}" x="${marker.x - contract.markers.size / 2}" y="${marker.y - contract.markers.size / 2}" width="${contract.markers.size}" height="${contract.markers.size}" fill="black"/>`);
  }
  function bubble(x: number, y: number, radius: number, label: string, selected: boolean, attributes: string): void {
    output.push(`<circle ${attributes} cx="${n(x)}" cy="${n(y)}" r="${n(radius)}" fill="${selected ? 'black' : 'white'}" stroke="#666" stroke-width="1"/>`);
    if (!selected) output.push(`<text x="${n(x)}" y="${n(y + radius * 0.3)}" text-anchor="middle" font-family="sans-serif" font-size="${n(radius * 0.9)}" fill="#999">${label}</text>`);
  }
  for (const column of template.columns) {
    for (let q = column.startQuestion; q <= column.endQuestion; q++) {
      const y = column.baseY + (q - column.startQuestion) * column.stepY;
      output.push(`<text x="${n(column.baseX - column.radius - 5)}" y="${n(y + 3)}" text-anchor="end" font-family="sans-serif" font-size="9">${q}</text>`);
      contract.options.forEach((option, index) => bubble(column.baseX + index * column.stepX, y, column.radius, option, (marks.answers[q] ?? []).includes(option as OptionKey), `data-question="${q}" data-option="${option}"`));
    }
  }
  const grid = template.studentId;
  output.push(`<text x="${n(grid.baseX)}" y="${n(grid.baseY - grid.radius - 12)}" font-family="sans-serif" font-size="9">7-digit scan code (not a student account)</text>`);
  marks.idDigits.forEach((digits, column) => {
    for (let digit = 0; digit <= 9; digit++) {
      bubble(grid.baseX + column * grid.stepX, grid.baseY + digit * grid.stepY, grid.radius, String(digit), digits.includes(digit), `data-id-column="${column}" data-digit="${digit}"`);
    }
  });
  return output.join('\n');
}

/** Fixed geometry test artifact. This does not certify the existing responsive HTML print layout. */
export async function buildScannerFixture(questionCount: number, marks: FixtureMarks) {
  const template = getScannerTemplate(questionCount);
  validateMarks(template, marks);
  const encoded = new TextEncoder().encode(JSON.stringify(contract));
  const hash = new Uint8Array(await crypto.subtle.digest('SHA-256', encoded));
  const geometryHash = Array.from(hash, (byte) => byte.toString(16).padStart(2, '0')).join('');
  const questions = Array.from({ length: questionCount }, (_, index) => {
    const questionNumber = index + 1;
    const selected = contract.options.filter((option) => (marks.answers[questionNumber] ?? []).includes(option as OptionKey));
    return { questionNumber, selected, status: selected.length === 0 ? 'blank' : selected.length === 1 ? 'single' : 'multiple' };
  });
  const decodedDigits = marks.idDigits.map((digits) => digits.length === 1 ? String(digits[0]) : '?');
  const truth = {
    schemaVersion: 1,
    kind: 'synthetic-svg-regression-fixture',
    templateId: template.id,
    geometryVersion: contract.geometryVersion,
    geometryHash,
    physicallyValidated: false,
    questionCount,
    questions,
    idDigits: marks.idDigits.map((digits) => [...digits]),
    expectedId: decodedDigits.every((digit) => digit === '?') ? 'NO-ID' : decodedDigits.join(''),
    requiresIdentityReview: decodedDigits.includes('?'),
    /** No exam identity mechanism exists in the current scanner. Do not imply this is a production form. */
    examIdentitySupported: false,
  };
  const metadata = `<metadata>${JSON.stringify({ templateId: template.id, geometryVersion: contract.geometryVersion, geometryHash })}</metadata>`;
  const sheet = renderSheet(template, marks);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="180mm" height="234mm" viewBox="0 0 600 780">${metadata}\n${sheet}\n</svg>\n`;
  const paper = contract.paper;
  const pageSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="${paper.widthMm}mm" height="${paper.heightMm}mm" viewBox="0 0 ${paper.widthMm} ${paper.heightMm}">${metadata}<rect width="210" height="297" fill="white"/><g transform="translate(${paper.contentXmm} ${paper.contentYmm}) scale(${paper.mmPerUnit})">${sheet}</g></svg>\n`;
  return { svg, pageSvg, truth };
}
