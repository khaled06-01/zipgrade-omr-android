export type OptionKey = 'A' | 'B' | 'C' | 'D';

export type QuestionCountPreset = 10 | 16 | 20 | 30 | 50 | 100;

export const QUESTION_PRESETS: QuestionCountPreset[] = [10, 20, 30, 50, 100];

export interface SheetMetadata {
  studentName: string;
  teacherName: string;
  sheetCode: string;
  yearHeader: string;
  semesterHeader: string;
  subjectHeader: string;
  sectionHeader: string;
  rosterHeader: string;
  optionLanguage: 'EN' | 'AR';
  shadingStyle: 'organic' | 'clean';
  singleChoiceLock: boolean;
}

export interface IdColumnState {
  writtenDigit: string; // '' or '0'-'9'
  shadedDigits: number[]; // e.g., [4]
}

export interface SheetLayout {
  questionCount: number;
  fullColumns: number[][];
  idColumnQuestions: number[];
  density: 'spacious' | 'normal' | 'compact' | 'ultra-compact';
}

export interface QuestionGradeResult {
  questionNumber: number;
  selected: OptionKey[];
  correctAnswer: OptionKey;
  status: 'correct' | 'wrong' | 'double-marked' | 'unanswered';
}

export interface SheetGradeSummary {
  totalQuestions: number;
  correctCount: number;
  wrongCount: number;
  doubleMarkedCount: number;
  unansweredCount: number;
  scorePercentage: number;
  results: Record<number, QuestionGradeResult>;
}

export const DEFAULT_METADATA: SheetMetadata = {
  studentName: '',
  teacherName: 'أ / محمد القرني',
  sheetCode: 'n (6353)',
  yearHeader: 'العام الدراسي',
  semesterHeader: 'الفصل',
  subjectHeader: 'رياضيات 3',
  sectionHeader: 'الشعبة',
  rosterHeader: 'الرقم في الكشف',
  optionLanguage: 'EN',
  shadingStyle: 'organic',
  singleChoiceLock: false,
};

export const REFERENCE_SHADED_ANSWERS: Record<number, OptionKey[]> = {
  1: ['A'],
  2: ['B'],
  3: ['B'],
  4: ['C'],
  5: ['D'],
  6: ['D'],
  7: ['D'],
  8: ['D'],
  9: ['C'],
  10: ['C'],
  11: ['C'],
  12: ['B', 'C'], // Double-marked in the reference image
  13: ['B'],
  14: ['D'],
  15: ['D'],
  16: ['A'],
};

export const REFERENCE_ID_COLUMNS: IdColumnState[] = [
  { writtenDigit: '4', shadedDigits: [4] },
  { writtenDigit: '6', shadedDigits: [6] },
  { writtenDigit: '3', shadedDigits: [3] },
  { writtenDigit: '3', shadedDigits: [3] },
  { writtenDigit: '', shadedDigits: [1] },
  { writtenDigit: '', shadedDigits: [6] },
  { writtenDigit: '', shadedDigits: [6] },
];

export function createBlankIdColumns(): IdColumnState[] {
  return Array.from({ length: 7 }, () => ({
    writtenDigit: '',
    shadedDigits: [],
  }));
}

export function range(start: number, endInclusive: number): number[] {
  const result: number[] = [];
  for (let i = start; i <= endInclusive; i++) {
    result.push(i);
  }
  return result;
}

/**
 * Computes the column layout for 10, 16, 20, 30, 50, 100 (or custom) questions
 * so that the question columns and the right-hand ID column + overflow questions
 * balance cleanly inside a single OMR frame.
 */
export function getSheetLayout(questionCount: number): SheetLayout {
  const count = Math.max(1, Math.min(100, Math.floor(questionCount)));

  if (count <= 12) {
    // 10 questions: 1 column of 1..10 on the left, ID block on the right
    return {
      questionCount: count,
      fullColumns: [range(1, count)],
      idColumnQuestions: [],
      density: 'spacious',
    };
  }

  if (count === 16) {
    // Exact match to reference image: 1..13 on left, 14..16 above ID block on right
    return {
      questionCount: 16,
      fullColumns: [range(1, 13)],
      idColumnQuestions: range(14, 16),
      density: 'normal',
    };
  }

  if (count <= 20) {
    // 20 questions: 1..14 on left, 15..20 above ID block on right
    const leftCount = Math.min(14, count);
    return {
      questionCount: count,
      fullColumns: [range(1, leftCount)],
      idColumnQuestions: count > leftCount ? range(leftCount + 1, count) : [],
      density: 'normal',
    };
  }

  if (count <= 30) {
    // 30 questions: two columns of 13 (1..13, 14..26) + 27..30 above ID block
    const col1End = 13;
    const col2End = Math.min(26, count);
    return {
      questionCount: count,
      fullColumns: [
        range(1, col1End),
        range(col1End + 1, col2End),
      ],
      idColumnQuestions: count > col2End ? range(col2End + 1, count) : [],
      density: 'normal',
    };
  }

  if (count <= 50) {
    // 50 questions: two columns of 22 (1..22, 23..44) + 45..50 (6 questions) above ID block
    const col1End = Math.min(22, count);
    const col2End = Math.min(44, count);
    return {
      questionCount: count,
      fullColumns:
        count > col1End
          ? [range(1, col1End), range(col1End + 1, col2End)]
          : [range(1, col1End)],
      idColumnQuestions: count > col2End ? range(col2End + 1, count) : [],
      density: 'compact',
    };
  }

  // 51..100 questions: three columns of 30 (1..30, 31..60, 61..90) + 91..100 (10 questions) above ID block
  const colRows = Math.ceil((count + 20) / 4); // For 100 -> (120)/4 = 30
  const fullColumns: number[][] = [];
  let current = 1;

  for (let c = 0; c < 3 && current <= count; c++) {
    const end = Math.min(current + colRows - 1, count);
    fullColumns.push(range(current, end));
    current = end + 1;
  }

  const idColumnQuestions = current <= count ? range(current, count) : [];

  return {
    questionCount: count,
    fullColumns,
    idColumnQuestions,
    density: 'ultra-compact',
  };
}

/**
 * Toggles an answer bubble for a given question.
 */
export function toggleQuestionOption(
  currentAnswers: Record<number, OptionKey[]>,
  questionNumber: number,
  option: OptionKey,
  singleChoiceLock: boolean
): Record<number, OptionKey[]> {
  const existing = currentAnswers[questionNumber] ?? [];
  const isSelected = existing.includes(option);

  let nextForQuestion: OptionKey[];
  if (singleChoiceLock) {
    nextForQuestion = isSelected ? [] : [option];
  } else {
    nextForQuestion = isSelected
      ? existing.filter((o) => o !== option)
      : [...existing, option];
  }

  const next = { ...currentAnswers };
  if (nextForQuestion.length === 0) {
    delete next[questionNumber];
  } else {
    next[questionNumber] = nextForQuestion;
  }
  return next;
}

/**
 * Toggles a digit bubble in the 7-column Student ID grid.
 */
export function toggleIdBubble(
  columns: IdColumnState[],
  colIndex: number,
  digit: number,
  singleChoiceLock: boolean
): IdColumnState[] {
  return columns.map((col, idx) => {
    if (idx !== colIndex) return col;
    const exists = col.shadedDigits.includes(digit);
    let nextShaded: number[];
    if (singleChoiceLock) {
      nextShaded = exists ? [] : [digit];
    } else {
      nextShaded = exists
        ? col.shadedDigits.filter((d) => d !== digit)
        : [...col.shadedDigits, digit];
    }
    const nextWritten =
      nextShaded.length === 1 ? String(nextShaded[0]) : nextShaded.length === 0 ? '' : col.writtenDigit;
    return {
      writtenDigit: nextWritten,
      shadedDigits: nextShaded,
    };
  });
}

/**
 * Generates a deterministic default answer key for grading.
 */
export function generateDefaultAnswerKey(questionCount: number): Record<number, OptionKey> {
  const options: OptionKey[] = ['A', 'B', 'C', 'D'];
  const key: Record<number, OptionKey> = {};
  for (let q = 1; q <= questionCount; q++) {
    // Match reference answers for 1..16 where single-marked so demo grading is meaningful
    const ref = REFERENCE_SHADED_ANSWERS[q];
    if (ref && ref.length === 1) {
      key[q] = ref[0];
    } else {
      key[q] = options[(q - 1) % 4];
    }
  }
  return key;
}

/**
 * Grades a student's shaded answers against an answer key.
 * Multiple shaded bubbles on a single question are flagged as 'double-marked' (invalid).
 */
export function gradeSheet(
  questionCount: number,
  shadedAnswers: Record<number, OptionKey[]>,
  answerKey: Record<number, OptionKey>
): SheetGradeSummary {
  const options: OptionKey[] = ['A', 'B', 'C', 'D'];
  let correctCount = 0;
  let wrongCount = 0;
  let doubleMarkedCount = 0;
  let unansweredCount = 0;
  const results: Record<number, QuestionGradeResult> = {};

  for (let q = 1; q <= questionCount; q++) {
    const selected = shadedAnswers[q] ?? [];
    const correctAnswer = answerKey[q] ?? options[(q - 1) % 4];

    let status: QuestionGradeResult['status'];
    if (selected.length === 0) {
      status = 'unanswered';
      unansweredCount++;
    } else if (selected.length > 1) {
      status = 'double-marked';
      doubleMarkedCount++;
    } else if (selected[0] === correctAnswer) {
      status = 'correct';
      correctCount++;
    } else {
      status = 'wrong';
      wrongCount++;
    }

    results[q] = {
      questionNumber: q,
      selected,
      correctAnswer,
      status,
    };
  }

  const scorePercentage =
    questionCount > 0 ? Math.round((correctCount / questionCount) * 100) : 0;

  return {
    totalQuestions: questionCount,
    correctCount,
    wrongCount,
    doubleMarkedCount,
    unansweredCount,
    scorePercentage,
    results,
  };
}
