import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildCustomSheet } from './customSheet';
import layout from '../templates/custom-android-v1.json';

test('all selectable counts emit their Android count marker and exactly that many question rows', () => {
  const words = new Set<string>();
  for (let count = 1; count <= 100; count++) {
    const { templateId, pageSvg } = buildCustomSheet(count);
    assert.equal(templateId, `CUSTOM_V1_${count}`);
    const cells = new Set(Array.from(pageSvg.matchAll(/data-count-cell="(\d+)"/g), ([, n]) => Number(n)));
    const word = layout.cellCentres.map((_, i) => cells.has(i) ? '1' : '0').join('');
    assert.equal(word, layout.codes[count - 1][1]);
    assert.equal(words.has(word), false);
    words.add(word);
    const answers = [...pageSvg.matchAll(/data-question="(\d+)" data-option="([A-D])"/g)];
    assert.equal(answers.length, count * 4);
    assert.equal(answers.at(-1)?.[1], String(count));
    assert.deepEqual(answers.slice(-4).map((entry) => entry[2]), ['A', 'B', 'C', 'D']);
    assert.equal((pageSvg.match(/data-marker=/g) ?? []).length, 6);
    assert.equal((pageSvg.match(/data-id-column=/g) ?? []).length, 70);
    assert.equal((pageSvg.match(/<circle[^>]*fill="#000"/g) ?? []).length, 0);
  }
});

test('37-question export carries the chosen responses and zero-padded ID', () => {
  const { pageSvg } = buildCustomSheet(37, {
    answers: { 1: ['B', 'D'], 37: ['A'] },
    idDigits: '0001234'.split('').map((d) => [Number(d)]),
  });
  assert.match(pageSvg, /width="210mm" height="297mm"/);
  assert.match(pageSvg, /data-question="37" data-option="A"[^>]*fill="#000"/);
  assert.match(pageSvg, /data-question="37" data-option="B"[^>]*fill="white"/);
  assert.match(pageSvg, /data-id-column="0" data-digit="0"[^>]*fill="#000"/);
  assert.equal((pageSvg.match(/<circle[^>]*fill="#000"/g) ?? []).length, 10);
});

test('fractional, out-of-range and nonfinite counts cannot be rendered', () => {
  for (const count of [0, -1, 101, 17.5, Infinity, NaN]) assert.throws(() => buildCustomSheet(count));
});
