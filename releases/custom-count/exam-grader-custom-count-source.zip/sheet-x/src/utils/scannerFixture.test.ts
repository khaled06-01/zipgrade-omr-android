import test from 'node:test';
import assert from 'node:assert/strict';
import { buildScannerFixture, getScannerTemplate, scannerTemplateContract } from './scannerFixture';

test('only explicit fixed geometries are accepted; responsive counts are not silently treated as compatible', () => {
  for (const unsupported of [0, 1, 15, 99, 101, NaN, Infinity]) assert.throws(() => getScannerTemplate(unsupported));
});

test('all fixed templates cover each question once and keep bubbles inside the six-marker frame', () => {
  for (const template of scannerTemplateContract.templates) {
    const questions: number[] = [];
    for (const column of template.columns) {
      for (let q = column.startQuestion; q <= column.endQuestion; q++) {
        questions.push(q);
        const y = column.baseY + (q - column.startQuestion) * column.stepY;
        assert.ok(y - column.radius > 64 && y + column.radius < 716);
      }
      assert.ok(column.baseX - column.radius > 64);
      assert.ok(column.baseX + 3 * column.stepX + column.radius < 536);
    }
    assert.deepEqual(questions, Array.from({ length: template.questionCount }, (_, i) => i + 1));
    assert.ok(template.studentId.baseX + 6 * template.studentId.stepX + template.studentId.radius < 536);
    assert.ok(template.studentId.baseY + 9 * template.studentId.stepY + template.studentId.radius < 716);
  }
  const paper = scannerTemplateContract.paper;
  assert.ok(paper.contentXmm >= paper.minimumMarginMm);
  assert.ok(paper.contentYmm >= paper.minimumMarginMm);
  assert.ok(paper.contentXmm + 600 * paper.mmPerUnit <= paper.widthMm - paper.minimumMarginMm);
  assert.ok(paper.contentYmm + 780 * paper.mmPerUnit <= paper.heightMm - paper.minimumMarginMm);
});

test('fixture truth preserves leading-zero scan codes, blanks and multiple marks', async () => {
  const fixture = await buildScannerFixture(16, { answers: { 1: ['A'], 12: ['C', 'B'] }, idDigits: '0033166'.split('').map((d) => [Number(d)]) });
  assert.equal(fixture.truth.expectedId, '0033166');
  assert.equal(fixture.truth.requiresIdentityReview, false);
  assert.equal(fixture.truth.questions[0].status, 'single');
  assert.equal(fixture.truth.questions[1].status, 'blank');
  assert.deepEqual(fixture.truth.questions[11].selected, ['B', 'C']);
  assert.equal(fixture.truth.questions[11].status, 'multiple');
  assert.equal(fixture.truth.physicallyValidated, false);
  assert.equal(fixture.truth.examIdentitySupported, false);
  assert.match(fixture.truth.geometryHash, /^[a-f0-9]{64}$/);
  assert.equal((fixture.svg.match(/data-marker=/g) ?? []).length, 6);
  assert.equal((fixture.svg.match(/data-question=/g) ?? []).length, 64);
  assert.equal((fixture.svg.match(/data-id-column=/g) ?? []).length, 70);
  assert.match(fixture.pageSvg, /width="210mm" height="297mm"/);
  assert.match(fixture.pageSvg, /translate\(15 31.5\) scale\(0.3\)/);
});

test('ambiguous and unreadable identity stays unresolved in ground truth', async () => {
  const partial = await buildScannerFixture(10, { answers: {}, idDigits: [[0, 1], [0], [3], [3], [1], [6], [6]] });
  assert.equal(partial.truth.expectedId, '?033166');
  assert.equal(partial.truth.requiresIdentityReview, true);
  const blank = await buildScannerFixture(10, { answers: {}, idDigits: Array.from({ length: 7 }, () => []) });
  assert.equal(blank.truth.expectedId, 'NO-ID');
  assert.equal(blank.truth.requiresIdentityReview, true);
});

test('invalid fixture data is rejected instead of generating misleading truth', async () => {
  await assert.rejects(buildScannerFixture(10, { answers: {}, idDigits: [] }));
  await assert.rejects(buildScannerFixture(10, { answers: {}, idDigits: [[10], [], [], [], [], [], []] }));
  await assert.rejects(buildScannerFixture(10, { answers: { 11: ['A'] }, idDigits: Array.from({ length: 7 }, () => []) }));
  await assert.rejects(buildScannerFixture(10, { answers: { 1: ['A', 'A'] }, idDigits: Array.from({ length: 7 }, () => []) }));
});
