import React from 'react';
import {
  Printer,
  Eraser,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Sliders,
  FileCheck2,
  Eye,
  Copy,
} from 'lucide-react';
import {
  SheetMetadata,
  SheetGradeSummary,
  OptionKey,
} from '../utils/omrLogic';

interface ControlPanelProps {
  questionCount: number;
  onSelectQuestionCount: (count: number) => void;
  metadata: SheetMetadata;
  onUpdateMetadata: (patch: Partial<SheetMetadata>) => void;
  onClearSheet: () => void;
  onLoadReferenceSample: () => void;
  onFillAllSample: () => void;
  onPrint: () => void;
  activeTab: 'customize' | 'grading' | 'reference';
  onSetActiveTab: (tab: 'customize' | 'grading' | 'reference') => void;
  gradeSummary: SheetGradeSummary;
  answerKey: Record<number, OptionKey>;
  onSetAnswerKeyOption: (qNum: number, opt: OptionKey) => void;
  twoUpPrint: boolean;
  onToggleTwoUpPrint: (val: boolean) => void;
}

const MAIN_PRESETS = [10, 20, 30, 50, 100];
const OPTIONS: OptionKey[] = ['A', 'B', 'C', 'D'];

export const ControlPanel: React.FC<ControlPanelProps> = ({
  questionCount,
  onSelectQuestionCount,
  metadata,
  onUpdateMetadata,
  onClearSheet,
  onLoadReferenceSample,
  onFillAllSample,
  onPrint,
  activeTab,
  onSetActiveTab,
  gradeSummary,
  answerKey,
  onSetAnswerKeyOption,
  twoUpPrint,
  onToggleTwoUpPrint,
}) => {
  return (
    <aside
      dir="rtl"
      className="w-full lg:w-[400px] xl:w-[430px] shrink-0 bg-white border border-slate-200 rounded-xl p-5 shadow-sm print:hidden flex flex-col gap-5"
    >
      {/* 1. Primary Question Count Selector: 10, 20, 30, 50, 100 */}
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <h2 className="text-sm font-bold text-slate-900">
            عدد الأسئلة (Question Count)
          </h2>
          <span className="text-xs font-mono tabular-nums text-slate-500">
            {questionCount} سؤال
          </span>
        </div>

        <div
          role="group"
          aria-label="Question Count Presets"
          className="grid grid-cols-5 gap-1.5 bg-slate-100 p-1.5 rounded-lg"
        >
          {MAIN_PRESETS.map((preset) => {
            const isActive = questionCount === preset;
            return (
              <button
                key={preset}
                type="button"
                onClick={() => onSelectQuestionCount(preset)}
                className={`py-2 px-2 rounded-md font-mono font-bold text-sm tabular-nums transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200/80'
                }`}
              >
                {preset}
              </button>
            );
          })}
        </div>

        {/* Exact 16-Question Reference Button + Custom Number Slider */}
        <div className="mt-2.5 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => onSelectQuestionCount(16)}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 border ${
              questionCount === 16
                ? 'bg-sky-50 border-sky-600 text-sky-900'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            16 سؤال (مطابق للصورة المرفقة)
          </button>

          <div className="flex items-center gap-1.5">
            <label
              htmlFor="custom-q-count"
              className="text-xs text-slate-600 whitespace-nowrap"
            >
              مخصص:
            </label>
            <input
              id="custom-q-count"
              type="number"
              min={1}
              max={100}
              value={questionCount}
              onChange={(e) => {
                const v = parseInt(e.target.value, 10);
                if (!Number.isNaN(v)) {
                  onSelectQuestionCount(Math.max(1, Math.min(100, v)));
                }
              }}
              className="w-16 px-2 py-1 text-center font-mono text-xs font-bold border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>
        </div>
      </div>

      {/* 2. Quick Sheet State Actions (Blank for Print vs Shaded Sample) */}
      <div className="border-t border-slate-200 pt-4">
        <h3 className="text-xs font-bold text-slate-700 mb-2.5">
          حالة التظليل والطباعة السريعة
        </h3>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={onClearSheet}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            <Eraser className="w-3.5 h-3.5 text-slate-600 shrink-0" />
            <span>ورقة فارغة للطباعة</span>
          </button>

          <button
            type="button"
            onClick={onLoadReferenceSample}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-600 shrink-0" />
            <span>التظليل المرفق</span>
          </button>

          <button
            type="button"
            onClick={onFillAllSample}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-600 shrink-0" />
            <span>تظليل كامل ({questionCount})</span>
          </button>

          <button
            type="button"
            onClick={onPrint}
            className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold transition-colors shadow-sm whitespace-nowrap shrink-0"
          >
            <Printer className="w-3.5 h-3.5 shrink-0" />
            <span>طباعة الورقة (A4)</span>
          </button>
        </div>
      </div>

      {/* 3. Mode Switcher Tabs: Customize | Auto-Grading | Reference Image */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg border border-slate-200/60">
        <button
          type="button"
          onClick={() => onSetActiveTab('customize')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'customize'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Sliders className="w-3.5 h-3.5 shrink-0" />
          <span>إعدادات الورقة</span>
        </button>

        <button
          type="button"
          onClick={() => onSetActiveTab('grading')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'grading'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileCheck2 className="w-3.5 h-3.5 shrink-0" />
          <span>التصحيح الآلي</span>
        </button>

        <button
          type="button"
          onClick={() => onSetActiveTab('reference')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'reference'
              ? 'bg-white text-slate-900 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Eye className="w-3.5 h-3.5 shrink-0" />
          <span>الصورة المرفقة</span>
        </button>
      </div>

      {/* 4. Tab Content */}
      {activeTab === 'customize' && (
        <div className="flex flex-col gap-3.5 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="meta-teacher"
                className="block font-semibold text-slate-700 mb-1"
              >
                اسم المعلم (الهامش الأيسر)
              </label>
              <input
                id="meta-teacher"
                type="text"
                value={metadata.teacherName}
                onChange={(e) =>
                  onUpdateMetadata({ teacherName: e.target.value })
                }
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label
                htmlFor="meta-subject"
                className="block font-semibold text-slate-700 mb-1"
              >
                المادة الدراسية
              </label>
              <input
                id="meta-subject"
                type="text"
                value={metadata.subjectHeader}
                onChange={(e) =>
                  onUpdateMetadata({ subjectHeader: e.target.value })
                }
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="meta-code"
                className="block font-semibold text-slate-700 mb-1"
              >
                كود النموذج (الهامش الأيمن)
              </label>
              <input
                id="meta-code"
                type="text"
                dir="ltr"
                value={metadata.sheetCode}
                onChange={(e) =>
                  onUpdateMetadata({ sheetCode: e.target.value })
                }
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md font-mono text-left focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div>
              <label
                htmlFor="meta-student"
                className="block font-semibold text-slate-700 mb-1"
              >
                اسم الطالب (اختياري)
              </label>
              <input
                id="meta-student"
                type="text"
                placeholder="اتركه فارغاً للطباعة"
                value={metadata.studentName}
                onChange={(e) =>
                  onUpdateMetadata({ studentName: e.target.value })
                }
                className="w-full px-2.5 py-1.5 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* Option Language & Shading Style */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div>
              <span className="block font-semibold text-slate-700 mb-1">
                حروف الاختيارات
              </span>
              <div className="flex bg-slate-100 p-1 rounded-md">
                <button
                  type="button"
                  onClick={() => onUpdateMetadata({ optionLanguage: 'EN' })}
                  className={`flex-1 py-1 rounded text-xs font-bold transition-colors whitespace-nowrap ${
                    metadata.optionLanguage === 'EN'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  A B C D
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateMetadata({ optionLanguage: 'AR' })}
                  className={`flex-1 py-1 rounded text-xs font-bold transition-colors whitespace-nowrap ${
                    metadata.optionLanguage === 'AR'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  أ ب ج د
                </button>
              </div>
            </div>

            <div>
              <span className="block font-semibold text-slate-700 mb-1">
                نمط التظليل
              </span>
              <div className="flex bg-slate-100 p-1 rounded-md">
                <button
                  type="button"
                  onClick={() => onUpdateMetadata({ shadingStyle: 'organic' })}
                  className={`flex-1 py-1 rounded text-xs font-bold transition-colors whitespace-nowrap ${
                    metadata.shadingStyle === 'organic'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  قلم يدوي
                </button>
                <button
                  type="button"
                  onClick={() => onUpdateMetadata({ shadingStyle: 'clean' })}
                  className={`flex-1 py-1 rounded text-xs font-bold transition-colors whitespace-nowrap ${
                    metadata.shadingStyle === 'clean'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600'
                  }`}
                >
                  دائري قياسي
                </button>
              </div>
            </div>
          </div>

          {/* Toggles for Single Choice Lock & 2-Up Print Mode */}
          <div className="flex flex-col gap-2 pt-1 border-t border-slate-100">
            <label className="flex items-center justify-between cursor-pointer py-1">
              <span className="font-medium text-slate-700">
                منع التظليل المزدوج للسؤال الواحد
              </span>
              <input
                type="checkbox"
                checked={metadata.singleChoiceLock}
                onChange={(e) =>
                  onUpdateMetadata({ singleChoiceLock: e.target.checked })
                }
                className="w-4 h-4 accent-sky-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between cursor-pointer py-1">
              <span className="font-medium text-slate-700 flex items-center gap-1.5">
                <Copy className="w-3.5 h-3.5 text-slate-500" />
                <span>عرض نسختين متجاورتين للطباعة (2-Up)</span>
              </span>
              <input
                type="checkbox"
                checked={twoUpPrint}
                onChange={(e) => onToggleTwoUpPrint(e.target.checked)}
                className="w-4 h-4 accent-sky-600 rounded"
              />
            </label>
          </div>
        </div>
      )}

      {activeTab === 'grading' && (
        <div className="flex flex-col gap-3.5">
          {/* Score Summary Banner */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3.5">
            <div className="flex items-baseline justify-between mb-2">
              <span className="text-xs font-bold text-slate-700">
                النتيجة النهائية
              </span>
              <div className="font-mono font-bold text-lg tabular-nums text-slate-900">
                {gradeSummary.correctCount} / {gradeSummary.totalQuestions}{' '}
                <span className="text-xs text-sky-700">
                  ({gradeSummary.scorePercentage}%)
                </span>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs pt-2 border-t border-slate-200/80">
              <div className="flex items-center gap-1 text-emerald-700 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span className="tabular-nums">
                  صحيحة: {gradeSummary.correctCount}
                </span>
              </div>
              <div className="flex items-center gap-1 text-rose-700 font-semibold">
                <XCircle className="w-3.5 h-3.5 shrink-0" />
                <span className="tabular-nums">
                  خاطئة: {gradeSummary.wrongCount}
                </span>
              </div>
              <div className="flex items-center gap-1 text-amber-700 font-semibold">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span className="tabular-nums">
                  مزدوجة: {gradeSummary.doubleMarkedCount}
                </span>
              </div>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            في وضع التصحيح الآلي، تُحاط الإجابة الصحيحة بحلقة خضراء. يمكنك النقر
            على أي دائرة في الورقة أو في القائمة أدناه لتغيير مفتاح الإجابة:
          </p>

          {/* Compact Scrollable Answer Key Editor */}
          <div className="max-h-56 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100 p-2 grid grid-cols-2 gap-1.5">
            {Array.from({ length: questionCount }, (_, idx) => {
              const qNum = idx + 1;
              const currentKey =
                answerKey[qNum] ?? OPTIONS[(qNum - 1) % 4];
              const qStatus = gradeSummary.results[qNum]?.status;

              return (
                <div
                  key={qNum}
                  className="flex items-center justify-between px-2 py-1 rounded bg-slate-50/70"
                >
                  <span className="font-mono text-xs font-bold tabular-nums text-slate-800">
                    س{qNum}
                  </span>
                  <div className="flex items-center gap-1" dir="ltr">
                    {OPTIONS.map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => onSetAnswerKeyOption(qNum, opt)}
                        className={`w-5 h-5 rounded-full text-[10px] font-bold transition-colors ${
                          currentKey === opt
                            ? 'bg-emerald-600 text-white'
                            : 'bg-white border border-slate-300 text-slate-600 hover:border-slate-500'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                  <span className="text-[11px] font-bold">
                    {qStatus === 'correct' && (
                      <span className="text-emerald-600">✓</span>
                    )}
                    {qStatus === 'wrong' && (
                      <span className="text-rose-600">✗</span>
                    )}
                    {qStatus === 'double-marked' && (
                      <span className="text-amber-600">!</span>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeTab === 'reference' && (
        <div className="flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">
              النموذج الأصلي المرفق للمقارنة
            </span>
            <button
              type="button"
              onClick={() => {
                onSelectQuestionCount(16);
                onLoadReferenceSample();
              }}
              className="text-xs font-semibold text-sky-700 hover:underline"
            >
              تطبيق نفس الإعدادات (16 سؤال)
            </button>
          </div>
          <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50 p-2 flex items-center justify-center">
            <img
              src="/assets/aistudio/image_5e3882b3.png"
              alt="Reference OMR Answer Sheet"
              referrerPolicy="no-referrer"
              className="max-h-80 w-auto object-contain rounded"
            />
          </div>
        </div>
      )}
    </aside>
  );
};
