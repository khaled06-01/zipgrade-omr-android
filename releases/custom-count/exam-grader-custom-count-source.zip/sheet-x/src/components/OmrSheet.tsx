import React from 'react';
import {
  OptionKey,
  SheetMetadata,
  IdColumnState,
  getSheetLayout,
  SheetGradeSummary,
} from '../utils/omrLogic';

interface OmrSheetProps {
  questionCount: number;
  metadata: SheetMetadata;
  shadedAnswers: Record<number, OptionKey[]>;
  idColumns: IdColumnState[];
  onToggleAnswer: (questionNumber: number, option: OptionKey) => void;
  onToggleIdBubble: (colIndex: number, digit: number) => void;
  onWriteIdDigit: (colIndex: number, value: string) => void;
  onUpdateStudentName: (name: string) => void;
  gradingMode?: boolean;
  answerKey?: Record<number, OptionKey>;
  gradeSummary?: SheetGradeSummary | null;
  onSetAnswerKeyOption?: (questionNumber: number, option: OptionKey) => void;
  compactPrintCard?: boolean;
}

const OPTIONS: OptionKey[] = ['A', 'B', 'C', 'D'];
const ARABIC_OPTION_LABELS: Record<OptionKey, string> = {
  A: 'أ',
  B: 'ب',
  C: 'ج',
  D: 'د',
};

/**
 * Deterministic organic marker blob SVG path so shaded bubbles look like the
 * real black felt-tip marker shading in the reference OMR image.
 */
function OrganicBlobOverlay({ seed }: { seed: number }) {
  const variants = [
    'M 3,12 C 2,5 7,1 14,2 C 21,1 27,5 27,13 C 28,20 22,27 14,27 C 6,27 2,20 3,12 Z',
    'M 2,14 C 1,6 8,2 15,2 C 23,2 28,7 27,15 C 26,22 21,28 13,27 C 5,26 2,21 2,14 Z',
    'M 3,13 C 3,5 9,1 16,2 C 23,3 28,8 27,16 C 26,23 19,28 12,27 C 5,26 2,20 3,13 Z',
    'M 2,12 C 3,4 9,1 15,1 C 22,2 27,7 28,14 C 27,22 21,27 13,27 C 6,27 1,20 2,12 Z',
  ];
  const d = variants[Math.abs(seed) % variants.length];
  return (
    <svg
      viewBox="0 0 30 30"
      className="pointer-events-none absolute -inset-1 h-[calc(100%+8px)] w-[calc(100%+8px)] text-black"
      aria-hidden="true"
    >
      <path d={d} fill="currentColor" />
    </svg>
  );
}

export const OmrSheet: React.FC<OmrSheetProps> = ({
  questionCount,
  metadata,
  shadedAnswers,
  idColumns,
  onToggleAnswer,
  onToggleIdBubble,
  onWriteIdDigit,
  onUpdateStudentName,
  gradingMode = false,
  answerKey = {},
  gradeSummary = null,
  onSetAnswerKeyOption,
  compactPrintCard = false,
}) => {
  const layout = getSheetLayout(questionCount);
  const { density } = layout;

  // Sizing classes tuned per question count density so 10, 20, 30, 50, and 100 all fit cleanly
  const rowGapClass =
    density === 'spacious'
      ? 'space-y-3.5'
      : density === 'normal'
      ? 'space-y-2.5'
      : density === 'compact'
      ? 'space-y-1.5'
      : 'space-y-1';

  const bubbleSizeClass =
    density === 'spacious'
      ? 'w-7 h-7 text-xs'
      : density === 'normal'
      ? 'w-6 h-6 text-[11px]'
      : density === 'compact'
      ? 'w-5 h-5 text-[10px]'
      : 'w-4 h-4 text-[9px]';

  const bubbleGapClass =
    density === 'spacious'
      ? 'gap-2'
      : density === 'normal'
      ? 'gap-1.5'
      : density === 'compact'
      ? 'gap-1'
      : 'gap-1';

  const qNumClass =
    density === 'spacious'
      ? 'w-6 text-base'
      : density === 'normal'
      ? 'w-6 text-sm'
      : density === 'compact'
      ? 'w-5 text-xs'
      : 'w-5 text-[10px]';

  const idBubbleSizeClass =
    density === 'ultra-compact'
      ? 'w-4 h-4 text-[9px]'
      : density === 'compact'
      ? 'w-5 h-5 text-[10px]'
      : 'w-6 h-6 text-[11px]';

  const idRowPyClass =
    density === 'ultra-compact'
      ? 'py-0.5'
      : density === 'compact'
      ? 'py-1'
      : 'py-1.5';

  // Left barcode timing track pattern (11 bars matching the reference image)
  const barcodePattern = [
    'h-1.5', // thick
    'h-1',   // thin
    'h-2.5', // extra thick
    'h-1',   // thin
    'h-1',   // thin
    'h-2',   // thick
    'h-1',   // thin
    'h-2',   // thick
    'h-1',   // thin
    'h-1.5', // medium
    'h-1',   // thin
  ];

  const renderQuestionRow = (qNum: number) => {
    const selected = shadedAnswers[qNum] ?? [];
    const qResult = gradeSummary?.results[qNum];
    const correctOpt = answerKey[qNum] ?? OPTIONS[(qNum - 1) % 4];

    return (
      <div
        key={qNum}
        data-testid={`question-row-${qNum}`}
        className="flex items-center gap-1.5 select-none"
      >
        <span
          className={`${qNumClass} font-mono font-bold tabular-nums text-right text-black leading-none shrink-0`}
        >
          {qNum}
        </span>

        <div className={`flex items-center ${bubbleGapClass}`}>
          {OPTIONS.map((opt, optIdx) => {
            const isShaded = selected.includes(opt);
            const isCorrectKey = gradingMode && correctOpt === opt;
            const displayLabel =
              metadata.optionLanguage === 'AR' ? ARABIC_OPTION_LABELS[opt] : opt;

            return (
              <button
                key={opt}
                type="button"
                aria-label={`Question ${qNum} Option ${opt}`}
                aria-pressed={isShaded}
                onClick={() => {
                  if (gradingMode && onSetAnswerKeyOption) {
                    onSetAnswerKeyOption(qNum, opt);
                  } else {
                    onToggleAnswer(qNum, opt);
                  }
                }}
                className={`relative rounded-full border border-neutral-500 flex items-center justify-center font-sans font-medium transition-transform active:scale-95 focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-500 ${bubbleSizeClass} ${
                  isShaded && metadata.shadingStyle === 'clean'
                    ? 'bg-black text-black border-black'
                    : 'bg-white text-neutral-500 hover:border-black'
                } ${
                  isCorrectKey
                    ? 'ring-2 ring-emerald-600 ring-offset-1 print:ring-0'
                    : ''
                }`}
              >
                <span className="relative z-0 leading-none">{displayLabel}</span>
                {isShaded && metadata.shadingStyle === 'organic' && (
                  <OrganicBlobOverlay seed={qNum * 7 + optIdx * 13} />
                )}
              </button>
            );
          })}
        </div>

        {/* Grading Status Indicator (Hidden when printing) */}
        {gradingMode && qResult && (
          <span
            className="print:hidden ml-0.5 text-[10px] font-bold leading-none shrink-0"
            title={
              qResult.status === 'correct'
                ? 'إجابة صحيحة'
                : qResult.status === 'double-marked'
                ? 'تظليل مزدوج (لاغية)'
                : qResult.status === 'wrong'
                ? `خاطئة (الصحيح ${qResult.correctAnswer})`
                : 'بدون إجابة'
            }
          >
            {qResult.status === 'correct' && (
              <span className="text-emerald-600">✓</span>
            )}
            {qResult.status === 'wrong' && (
              <span className="text-rose-600">✗</span>
            )}
            {qResult.status === 'double-marked' && (
              <span className="text-amber-600">!</span>
            )}
            {qResult.status === 'unanswered' && (
              <span className="text-slate-400">–</span>
            )}
          </span>
        )}
      </div>
    );
  };

  return (
    <div
      dir="ltr"
      data-testid="omr-sheet-canvas"
      data-question-count={questionCount}
      className={`relative bg-white text-black border-2 border-black shadow-xl print:shadow-none mx-auto select-none ${
        compactPrintCard
          ? 'w-full max-w-[520px] p-3'
          : questionCount > 50
          ? 'w-full max-w-[820px] p-5 sm:p-7'
          : questionCount > 20
          ? 'w-full max-w-[680px] p-5 sm:p-7'
          : 'w-full max-w-[560px] p-5 sm:p-7'
      }`}
    >
      {/* 1. TOP ROW: Top-Left Fiducial, Student Name Box, "الاسم" Badge, Top-Right Fiducial */}
      <div className="flex items-start justify-between gap-3 mb-5">
        {/* Top-Left Black Square Fiducial */}
        <div
          className="w-5 h-5 bg-black shrink-0 mt-0.5"
          aria-hidden="true"
        />

        {/* Center Header: Name Input Box + "الاسم" Gray Rounded Box */}
        <div className="flex-1 flex items-stretch gap-2.5 max-w-[90%] mx-auto">
          <div className="flex-1 border-[1.5px] border-black bg-white h-12 flex items-center px-3">
            <input
              type="text"
              dir="rtl"
              aria-label="Student Name"
              value={metadata.studentName}
              onChange={(e) => onUpdateStudentName(e.target.value)}
              placeholder=""
              className="w-full h-full bg-transparent text-right font-bold text-base text-black focus:outline-none"
            />
          </div>
          <div
            dir="rtl"
            className="w-24 sm:w-28 h-12 rounded-md border-[1.5px] border-black bg-[#d6d6d6] flex items-center justify-center font-extrabold text-xl tracking-wide text-black shrink-0"
          >
            الاسم
          </div>
        </div>

        {/* Top-Right Black Square Fiducial */}
        <div
          className="w-5 h-5 bg-black shrink-0 mt-0.5"
          aria-hidden="true"
        />
      </div>

      {/* 2. MAIN BODY: Left Margin Track + Question Columns + Right ID Column + Right Margin Track */}
      <div className="relative flex items-stretch justify-between gap-2 sm:gap-4">
        {/* LEFT MARGIN COLUMN (Teacher Vertical Signature, Mid-Left Square, Timing Barcode) */}
        <div className="w-6 flex flex-col items-center justify-between py-2 shrink-0">
          {/* Teacher Name rotated vertically like "أ / محمد القرني" in the reference image */}
          <div className="h-32 flex items-center justify-center">
            <span
              dir="rtl"
              style={{ writingMode: 'vertical-rl' }}
              className="font-serif font-bold text-sm sm:text-base text-neutral-800 whitespace-nowrap tracking-normal rotate-180"
            >
              {metadata.teacherName}
            </span>
          </div>

          {/* Middle-Left Fiducial Square */}
          <div className="w-5 h-5 bg-black my-4 shrink-0" aria-hidden="true" />

          {/* Barcode Timing Bars (Bottom-Left segment) */}
          <div
            className="flex flex-col justify-between gap-2 w-5 py-2"
            aria-hidden="true"
          >
            {barcodePattern.map((heightCls, idx) => (
              <div key={idx} className={`w-full bg-black ${heightCls}`} />
            ))}
          </div>
        </div>

        {/* CENTER CONTENT AREA: Full Question Columns + Right Column (Overflow Questions + 7-Col ID Grid) */}
        <div className="flex-1 flex flex-nowrap items-start justify-around gap-3 sm:gap-5 py-1">
          {/* Full Question Columns */}
          {layout.fullColumns.map((colQuestions, colIdx) => (
            <div
              key={colIdx}
              className="flex flex-col items-center justify-between"
            >
              <div className={`flex flex-col ${rowGapClass}`}>
                {colQuestions.map((qNum) => renderQuestionRow(qNum))}
              </div>

              {/* Bottom Calibration Black Circle under the first question column */}
              {colIdx === 0 && (
                <div
                  className="w-6 h-6 rounded-full bg-black mt-5 ml-8 shrink-0"
                  aria-hidden="true"
                />
              )}
            </div>
          ))}

          {/* Right-Most Column: Overflow Questions on top + 7-Column Student ID / Metadata Grid below */}
          <div className="flex flex-col items-start">
            {layout.idColumnQuestions.length > 0 && (
              <div className={`flex flex-col ${rowGapClass} mb-4`}>
                {layout.idColumnQuestions.map((qNum) => renderQuestionRow(qNum))}
              </div>
            )}

            {/* 7-COLUMN STUDENT ID / METADATA GRID (جدول البيانات والسجل) */}
            <div
              data-testid="student-id-grid"
              className="mt-1 flex flex-col"
            >
              {/* Group Header Boxes Row (5 Gray Rounded-Top Boxes spanning 7 columns: 2 + 1 + 1 + 1 + 2) */}
              <div className="grid grid-cols-7 gap-0.5 mb-0.5">
                {/* Col 0-1: العام الدراسي */}
                <div
                  dir="rtl"
                  className="col-span-2 h-14 rounded-t-md border-[1.5px] border-black bg-[#d6d6d6] flex items-center justify-center px-1 text-center font-bold text-xs leading-tight text-black"
                >
                  {metadata.yearHeader}
                </div>

                {/* Col 2: الفصل */}
                <div
                  dir="rtl"
                  className="col-span-1 h-14 rounded-t-md border-[1.5px] border-black bg-[#d6d6d6] flex items-center justify-center p-0.5 text-center font-bold text-[11px] leading-none text-black"
                >
                  <span
                    style={{ writingMode: 'vertical-rl' }}
                    className="rotate-180 whitespace-nowrap"
                  >
                    {metadata.semesterHeader}
                  </span>
                </div>

                {/* Col 3: المادة (رياضيات 3) */}
                <div
                  dir="rtl"
                  className="col-span-1 h-14 rounded-t-md border-[1.5px] border-black bg-[#d6d6d6] flex items-center justify-center p-0.5 text-center font-bold text-[11px] leading-none text-black"
                >
                  <span
                    style={{ writingMode: 'vertical-rl' }}
                    className="rotate-180 whitespace-nowrap"
                  >
                    {metadata.subjectHeader}
                  </span>
                </div>

                {/* Col 4: الشعبة */}
                <div
                  dir="rtl"
                  className="col-span-1 h-14 rounded-t-md border-[1.5px] border-black bg-[#d6d6d6] flex items-center justify-center p-0.5 text-center font-bold text-[11px] leading-none text-black"
                >
                  <span
                    style={{ writingMode: 'vertical-rl' }}
                    className="rotate-180 whitespace-nowrap"
                  >
                    {metadata.sectionHeader}
                  </span>
                </div>

                {/* Col 5-6: الرقم في الكشف */}
                <div
                  dir="rtl"
                  className="col-span-2 h-14 rounded-t-md border-[1.5px] border-black bg-[#d6d6d6] flex items-center justify-center px-1 text-center font-bold text-xs leading-tight text-black"
                >
                  {metadata.rosterHeader}
                </div>
              </div>

              {/* Lower Box Border containing Written Digits Row + 0..9 Bubbles Grid */}
              <div className="border border-neutral-400 bg-white">
                {/* 7 Written Digit Boxes Row */}
                <div className="grid grid-cols-7 border-b border-neutral-400">
                  {idColumns.map((col, colIdx) => (
                    <div
                      key={colIdx}
                      className={`h-9 flex items-center justify-center ${
                        colIdx < 6 ? 'border-r border-neutral-400' : ''
                      }`}
                    >
                      <input
                        type="text"
                        inputMode="numeric"
                        maxLength={1}
                        aria-label={`ID Digit Column ${colIdx + 1}`}
                        value={col.writtenDigit}
                        onChange={(e) => {
                          const val = e.target.value.replace(/[^0-9]/g, '');
                          onWriteIdDigit(colIdx, val);
                        }}
                        className="w-full h-full text-center font-sans text-xl font-semibold text-black bg-transparent focus:outline-none focus:bg-sky-50"
                      />
                    </div>
                  ))}
                </div>

                {/* 0..9 Bubble Rows across all 7 columns */}
                <div className="p-1.5 flex flex-col">
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((digit) => (
                    <div
                      key={digit}
                      className={`grid grid-cols-7 gap-1.5 place-items-center ${idRowPyClass}`}
                    >
                      {idColumns.map((col, colIdx) => {
                        const isShaded = col.shadedDigits.includes(digit);
                        return (
                          <button
                            key={colIdx}
                            type="button"
                            aria-label={`ID Column ${colIdx + 1} Digit ${digit}`}
                            aria-pressed={isShaded}
                            onClick={() => onToggleIdBubble(colIdx, digit)}
                            className={`relative rounded-full border border-neutral-500 flex items-center justify-center font-sans font-medium transition-transform active:scale-95 focus:outline-none ${idBubbleSizeClass} ${
                              isShaded && metadata.shadingStyle === 'clean'
                                ? 'bg-black text-black border-black'
                                : 'bg-white text-neutral-500 hover:border-black'
                            }`}
                          >
                            <span className="relative z-0 leading-none">
                              {digit}
                            </span>
                            {isShaded && metadata.shadingStyle === 'organic' && (
                              <OrganicBlobOverlay
                                seed={(digit + 1) * 19 + colIdx * 31}
                              />
                            )}
                          </button>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT MARGIN COLUMN (Sheet Code "n (6353)" & Mid-Right Fiducial Square) */}
        <div className="w-6 flex flex-col items-center justify-start py-6 shrink-0">
          <div className="h-32 flex items-center justify-center">
            <span
              style={{ writingMode: 'vertical-rl' }}
              className="font-sans font-medium text-base text-neutral-900 whitespace-nowrap rotate-180 tracking-wide"
            >
              {metadata.sheetCode}
            </span>
          </div>

          <div
            className="w-5 h-5 bg-black mt-16 shrink-0"
            aria-hidden="true"
          />
        </div>
      </div>

      {/* 3. BOTTOM ROW: Bottom-Left Fiducial Square & Bottom-Right Fiducial Square */}
      <div className="flex items-end justify-between mt-4">
        <div className="w-5 h-5 bg-black shrink-0" aria-hidden="true" />
        <div className="w-5 h-5 bg-black shrink-0" aria-hidden="true" />
      </div>
    </div>
  );
};
