/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from 'react';
import { OmrSheet } from './components/OmrSheet';
import { ControlPanel } from './components/ControlPanel';
import { buildCustomSheet } from './utils/customSheet';
import {
  OptionKey,
  SheetMetadata,
  IdColumnState,
  DEFAULT_METADATA,
  REFERENCE_SHADED_ANSWERS,
  REFERENCE_ID_COLUMNS,
  QUESTION_PRESETS,
  createBlankIdColumns,
  toggleQuestionOption,
  toggleIdBubble,
  generateDefaultAnswerKey,
  gradeSheet,
} from './utils/omrLogic';

export default function App() {
  const [questionCount, setQuestionCount] = useState<number>(20);
  const [metadata, setMetadata] = useState<SheetMetadata>(DEFAULT_METADATA);
  const [shadedAnswers, setShadedAnswers] = useState<Record<number, OptionKey[]>>(
    () => ({ ...REFERENCE_SHADED_ANSWERS })
  );
  const [idColumns, setIdColumns] = useState<IdColumnState[]>(() =>
    REFERENCE_ID_COLUMNS.map((c) => ({
      writtenDigit: c.writtenDigit,
      shadedDigits: [...c.shadedDigits],
    }))
  );
  const [activeTab, setActiveTab] = useState<'customize' | 'grading' | 'reference'>(
    'customize'
  );
  const [answerKey, setAnswerKey] = useState<Record<number, OptionKey>>(() =>
    generateDefaultAnswerKey(100)
  );
  const [twoUpPrint, setTwoUpPrint] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'single' | 'gallery'>('single');
  const [fixtureError, setFixtureError] = useState('');

  const gradeSummary = useMemo(
    () => gradeSheet(questionCount, shadedAnswers, answerKey),
    [questionCount, shadedAnswers, answerKey]
  );

  const handleUpdateMetadata = (patch: Partial<SheetMetadata>) => {
    setMetadata((prev) => ({ ...prev, ...patch }));
  };

  const handleToggleAnswer = (qNum: number, option: OptionKey) => {
    setShadedAnswers((prev) =>
      toggleQuestionOption(prev, qNum, option, metadata.singleChoiceLock)
    );
  };

  const handleToggleIdBubble = (colIndex: number, digit: number) => {
    setIdColumns((prev) =>
      toggleIdBubble(prev, colIndex, digit, metadata.singleChoiceLock)
    );
  };

  const handleWriteIdDigit = (colIndex: number, value: string) => {
    setIdColumns((prev) =>
      prev.map((col, idx) => {
        if (idx !== colIndex) return col;
        if (value === '') {
          return { writtenDigit: '', shadedDigits: [] };
        }
        const num = parseInt(value, 10);
        return {
          writtenDigit: value,
          shadedDigits: Number.isNaN(num) ? col.shadedDigits : [num],
        };
      })
    );
  };

  const handleClearSheet = () => {
    setShadedAnswers({});
    setIdColumns(createBlankIdColumns());
    setMetadata((prev) => ({ ...prev, studentName: '' }));
  };

  const handleLoadReferenceSample = () => {
    setShadedAnswers({ ...REFERENCE_SHADED_ANSWERS });
    setIdColumns(
      REFERENCE_ID_COLUMNS.map((c) => ({
        writtenDigit: c.writtenDigit,
        shadedDigits: [...c.shadedDigits],
      }))
    );
  };

  const handleFillAllSample = () => {
    const options: OptionKey[] = ['A', 'B', 'C', 'D'];
    const filled: Record<number, OptionKey[]> = {};
    for (let q = 1; q <= questionCount; q++) {
      if (REFERENCE_SHADED_ANSWERS[q]) {
        filled[q] = [...REFERENCE_SHADED_ANSWERS[q]];
      } else {
        filled[q] = [options[(q * 3 + 1) % 4]];
      }
    }
    setShadedAnswers(filled);
    setIdColumns(
      REFERENCE_ID_COLUMNS.map((c, idx) => ({
        writtenDigit:
          c.writtenDigit || String(c.shadedDigits[0] ?? (idx + 1) % 10),
        shadedDigits: [...c.shadedDigits],
      }))
    );
  };

  const handleSetAnswerKeyOption = (qNum: number, opt: OptionKey) => {
    setAnswerKey((prev) => ({ ...prev, [qNum]: opt }));
  };

  const handlePrint = () => {
    window.print();
  };

  const downloadScannerSheet = (withMarks: boolean) => {
    setFixtureError('');
    try {
      const answers = Object.fromEntries(
        Object.entries(shadedAnswers).filter(([number]) => Number(number) <= questionCount)
      );
      const { pageSvg, templateId } = buildCustomSheet(questionCount, withMarks ? {
        answers,
        idDigits: idColumns.map((col) => col.shadedDigits),
      } : undefined);
      const url = URL.createObjectURL(new Blob([pageSvg], { type: 'image/svg+xml' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `${templateId}${withMarks ? '-marked' : ''}-a4.svg`;
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      setFixtureError('تعذّر إنشاء الورقة. تحقق من عدد الأسئلة والمحاولات المظللة.');
    }
  };

  const shadedQuestionsCount = useMemo(() => {
    let count = 0;
    for (let q = 1; q <= questionCount; q++) {
      if ((shadedAnswers[q]?.length ?? 0) > 0) count++;
    }
    return count;
  }, [questionCount, shadedAnswers]);

  return (
    <div className="min-h-screen w-full overflow-x-hidden flex flex-col bg-slate-100 text-slate-900 print:bg-white">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header
        dir="rtl"
        className="flex items-center justify-between gap-4 sm:gap-8 px-4 sm:px-6 py-3.5 bg-white border-b border-slate-200 print:hidden"
      >
        {/* Zone 1: Brand Title (single text element) */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setViewMode('single');
          }}
          className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
        >
          مصمم أوراق التظليل OMR
        </a>

        {/* Zone 2: 5 concise single-line nav links for 10, 20, 30, 50, 100 questions */}
        <nav
          aria-label="نماذج عدد الأسئلة"
          className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-600"
        >
          {QUESTION_PRESETS.map((preset) => {
            const active = questionCount === preset && viewMode === 'single';
            return (
              <button
                key={preset}
                type="button"
                onClick={() => {
                  setQuestionCount(preset);
                  setViewMode('single');
                }}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                  active
                    ? 'text-slate-900 border-slate-900'
                    : 'border-transparent hover:text-slate-900 hover:border-slate-300'
                }`}
              >
                نموذج {preset}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={handlePrint}
            className="px-3.5 sm:px-4 py-2 text-xs font-bold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0"
          >
            طباعة النموذج
          </button>
        </div>
      </header>

      {/* Main Two-Zone Workspace */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-3 sm:px-6 py-5 sm:py-6 print:p-0 print:max-w-none">
        <div
          dir="rtl"
          className="flex flex-col lg:flex-row items-start gap-6 print:block min-w-0"
        >
          {/* Control & Grading Sidebar */}
          <ControlPanel
            questionCount={questionCount}
            onSelectQuestionCount={(count) => {
              setQuestionCount(count);
            }}
            metadata={metadata}
            onUpdateMetadata={handleUpdateMetadata}
            onClearSheet={handleClearSheet}
            onLoadReferenceSample={handleLoadReferenceSample}
            onFillAllSample={handleFillAllSample}
            onPrint={handlePrint}
            activeTab={activeTab}
            onSetActiveTab={setActiveTab}
            gradeSummary={gradeSummary}
            answerKey={answerKey}
            onSetAnswerKeyOption={handleSetAnswerKeyOption}
            twoUpPrint={twoUpPrint}
            onToggleTwoUpPrint={setTwoUpPrint}
          />

          {/* Interactive OMR Sheet Stage */}
          <section
            aria-label="معاينة ورقة الإجابة"
            className="flex-1 min-w-0 w-full flex flex-col gap-4 print:block"
          >
            {/* Quiet Unboxed Metadata & View Switcher Toolbar (Hidden in Print) */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-2xs print:hidden">
              {/* Unboxed Metadata with typographic separators */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                <span className="font-bold text-slate-900">
                  نموذج {questionCount} سؤال
                </span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">
                  المظلل: {shadedQuestionsCount} من {questionCount}
                </span>
                <span aria-hidden="true">·</span>
                <span>المادة: {metadata.subjectHeader}</span>
                <span aria-hidden="true">·</span>
                <span>
                  {activeTab === 'grading'
                    ? `وضع التصحيح (${gradeSummary.scorePercentage}%)`
                    : 'انقر على الدوائر للتظليل'}
                </span>
              </div>

              {/* Segmented View Toggle: Single Sheet vs All 5 Templates (10, 20, 30, 50, 100) */}
              {viewMode === 'single' && (
                <div className="flex flex-wrap gap-2">
                  <button type="button" onClick={() => downloadScannerSheet(false)}
                    className="px-3 py-2 text-xs font-semibold rounded-md bg-slate-900 text-white">
                    تنزيل ورقة ماسح فارغة ({questionCount} سؤالًا، A4)
                  </button>
                  <button type="button" onClick={() => downloadScannerSheet(true)}
                    className="px-3 py-2 text-xs font-semibold rounded-md border border-slate-300">
                    تنزيل بالتظليل الحالي
                  </button>
                </div>
              )}
              {fixtureError && <p role="alert" className="text-sm text-red-700">{fixtureError}</p>}
              <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg max-w-full">
                <button
                  type="button"
                  onClick={() => setViewMode('single')}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    viewMode === 'single'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ورقة تفاعلية مفردة
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('gallery')}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    viewMode === 'gallery'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  جميع النماذج (10–100)
                </button>
              </div>
            </div>

            {/* Sheet Canvas Rendering */}
            {viewMode === 'single' ? (
              <div
                className={
                  twoUpPrint
                    ? 'grid grid-cols-1 xl:grid-cols-2 print:grid-cols-2 gap-6 items-start overflow-x-auto pb-2'
                    : 'flex justify-center overflow-x-auto pb-2'
                }
              >
                <OmrSheet
                  questionCount={questionCount}
                  metadata={metadata}
                  shadedAnswers={shadedAnswers}
                  idColumns={idColumns}
                  onToggleAnswer={handleToggleAnswer}
                  onToggleIdBubble={handleToggleIdBubble}
                  onWriteIdDigit={handleWriteIdDigit}
                  onUpdateStudentName={(studentName) =>
                    handleUpdateMetadata({ studentName })
                  }
                  gradingMode={activeTab === 'grading'}
                  answerKey={answerKey}
                  gradeSummary={gradeSummary}
                  onSetAnswerKeyOption={handleSetAnswerKeyOption}
                  compactPrintCard={twoUpPrint}
                />

                {twoUpPrint && (
                  <OmrSheet
                    questionCount={questionCount}
                    metadata={metadata}
                    shadedAnswers={shadedAnswers}
                    idColumns={idColumns}
                    onToggleAnswer={handleToggleAnswer}
                    onToggleIdBubble={handleToggleIdBubble}
                    onWriteIdDigit={handleWriteIdDigit}
                    onUpdateStudentName={(studentName) =>
                      handleUpdateMetadata({ studentName })
                    }
                    gradingMode={activeTab === 'grading'}
                    answerKey={answerKey}
                    gradeSummary={gradeSummary}
                    onSetAnswerKeyOption={handleSetAnswerKeyOption}
                    compactPrintCard={true}
                  />
                )}
              </div>
            ) : (
              /* Gallery Mode: Shows 10, 20, 30, 50, 100 templates together */
              <div className="flex flex-col gap-8">
                {QUESTION_PRESETS.map((presetCount) => (
                  <div
                    key={presetCount}
                    className="bg-white/70 border border-slate-200 rounded-xl p-4 sm:p-6 print:border-none print:p-0 print:break-after-page"
                  >
                    <div className="flex items-center justify-between mb-4 print:hidden">
                      <div className="flex items-center gap-2 text-sm text-slate-700">
                        <span className="font-extrabold text-slate-900">
                          نموذج {presetCount} سؤال
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>تخطيط متوازن جاهز للطباعة</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setQuestionCount(presetCount);
                          setViewMode('single');
                        }}
                        className="px-3 py-1.5 text-xs font-bold text-slate-900 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
                      >
                        فتح وتخصيص نموذج {presetCount}
                      </button>
                    </div>

                    <OmrSheet
                      questionCount={presetCount}
                      metadata={metadata}
                      shadedAnswers={shadedAnswers}
                      idColumns={idColumns}
                      onToggleAnswer={handleToggleAnswer}
                      onToggleIdBubble={handleToggleIdBubble}
                      onWriteIdDigit={handleWriteIdDigit}
                      onUpdateStudentName={(studentName) =>
                        handleUpdateMetadata({ studentName })
                      }
                      gradingMode={activeTab === 'grading'}
                      answerKey={answerKey}
                      gradeSummary={gradeSheet(
                        presetCount,
                        shadedAnswers,
                        answerKey
                      )}
                      onSetAnswerKeyOption={handleSetAnswerKeyOption}
                    />
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}
